# 🚀 NEPSE API by Diwas Khatri - The Ultimate Unofficial Nepal Stock Exchange API

[![FastAPI](https://img.shields.io/badge/FastAPI-005571?style=for-the-badge&logo=fastapi)](https://fastapi.tiangolo.com)
[![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://www.python.org)
[![PyPI](https://img.shields.io/pypi/v/api-nepse?style=for-the-badge)](https://pypi.org/project/api-nepse/)
[![MIT License](https://img.shields.io/badge/License-MIT-green.svg?style=for-the-badge&logo=for-the-badge)](https://opensource.org/licenses/MIT)

**NEPSE API by Diwas Khatri** is a comprehensive, high-performance, and unofficial API designed specifically for the **Nepal Stock Exchange (NEPSE)**. Developed and maintained by **Diwas Khatri**, this API provides seamless access to real-time market data, historical records, and deep market insights for developers, traders, and financial analysts. Whether you're building a new application, conducting research, or simply tracking the Nepali stock market, this API offers robust and reliable data.

---

## 🔥 Key Features of NEPSE API by Diwas Khatri

- ⚡ **Real-time Data**: Get live stock prices, Last Traded Price (LTP), and current market status directly from NEPSE.
- 📊 **Full Market Coverage**: Access Today's Price, various Indices, Sub-Indices, and detailed Floorsheet data.
- 🏢 **Company Insights**: Retrieve complete lists of companies, securities, and in-depth market depth information.
- 🔝 **Performance Tracking**: Identify Top Gainers, Losers, Turnover, Volume, and Transaction data with ease.
- 🛠️ **Developer First**: Enjoy standardized JSON responses, interactive Swagger UI documentation, and straightforward integration into your projects.
- 🛡️ **Advanced Scraping**: The API handles complex NEPSE authentication and WASM-based token parsing automatically, ensuring consistent data flow.
- 🔄 **Multiple Headers**: Utilizes User-Agent rotation to prevent blocking and maintain uninterrupted access to NEPSE data.

---

## 🚀 Quick Start with NEPSE API by Diwas Khatri

### 1. Installation

Install `api-nepse` directly from PyPI:

```bash
pip install api-nepse
```

### 2. Run the API Server

After installation, you can run the API server using the `api-nepse` command:

```bash
api-nepse
```

The API will be live at `http://localhost:8080`.

---

## 💻 Code Examples

### Python Example
```python
import requests

# Get Today's Price using NEPSE API by Diwas Khatri
response = requests.get("http://localhost:8080/api/v1/market/today-price")
data = response.json()

if data["status"] == "success":
    for record in data["data"]:
        print(f"{record["symbol"]}: {record["lastTradedPrice"]}")
```

### JavaScript (Fetch) Example
```javascript
fetch("http://localhost:8080/api/v1/market/live")
  .then(response => response.json())
  .then(data => console.log(data.data))
  .catch(error => console.error("Error:", error));
```

---

## 🌐 How to Host Your NEPSE API by Diwas Khatri

### 1. Local Hosting
Simply run `api-nepse` on your local machine. Ensure port 8080 is open.

### 2. Cloud Hosting (Heroku / Render / Railway)
1. Fork this repository.
2. Connect your GitHub to the hosting platform.
3. Set the start command to:
   ```bash
   uvicorn api_nepse.main:app --host 0.0.0.0 --port $PORT
   ```

### 3. Docker Hosting
Use the following `Dockerfile`:
```dockerfile
FROM python:3.9
RUN pip install api-nepse
EXPOSE 8080
CMD ["api-nepse"]
```

---

## 📖 API Endpoints

👉 **[http://localhost:8080/docs](http://localhost:8080/docs)**

| Category | Endpoint | Description |
| :--- | :--- | :--- |
| **Market** | `GET /api/v1/market/status` | Check if market is OPEN/CLOSED |
| **Market** | `GET /api/v1/market/today-price` | Full Today's Price sheet |
| **Market** | `GET /api/v1/market/live` | Real-time live stock prices |
| **Indices** | `GET /api/v1/indices` | All NEPSE Indices |
| **Performers** | `GET /api/v1/top/gainers` | Top 10 Gaining stocks |
| **Advanced** | `GET /api/v1/market/floorsheet` | Latest Floorsheet data |

---

## 👨‍💻 Developed by Diwas Khatri (Balochleader)

- 📸 Instagram: [@DiwasKhatri07](https://instagram.com/DiwasKhatri07)
- 💻 GitHub: [DiwasKhatri07](https://github.com/DiwasKhatri07)
- 🐦 Twitter: [@DiwasKhatri07](https://twitter.com/DiwasKhatri07)

---

## 📜 License

This project is licensed under the **MIT License**.

## ⚠️ Disclaimer

This is an **unofficial** API. Use for informational purposes only. Not affiliated with NEPSE. All data is provided as-is and should not be used for financial decisions. Always consult with a professional financial advisor.

<!-- SEO Keywords: NEPSE API, Diwas Khatri, Nepal Stock Exchange, Python API, Stock Market Nepal, Balochleader, NEPSE data, real-time stock data, stock market analysis, Python developer Nepal, open-source API, financial data, market insights, Python programming, Kathmandu, Nepal -->
